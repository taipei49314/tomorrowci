def snapshot_value():
    return "python-snapshot-dependency-1.0.0"
