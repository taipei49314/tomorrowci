'use strict';
exports.snapshotValue = () => 'node-snapshot-dependency-1.0.0';
